// bubble sort algorithm

#include <stdio.h>
#include "bubbleSort.h"
#define SIZE 25

int main()
{
	int order;//1 - ascending 2 - descending
	int counter;

	int a[SIZE];
	int n;
	

	printf("Enter 1 to sort in ascending order, \n");
        printf("Enter 2 to sort in descending order, \n");
	scanf("%d", &order);

	// reading a 1D array
	printf("Read the size of the list.\n");
	scanf("%d", &n);

	printf("Enter %d elements one by one.\n", n);
	for (counter = 0;counter <= n-1; ++counter)

	    {
		scanf("%d", &a[counter]);
	    }

	if (order == 1)
	   { 
	      bubble(a, n, ascending);
	      printf("Data items in ascending order.\n");
           }
	else
	   {
	      bubble(a, n, descending);
              printf("Data items in descending order.\n");                               
           }
	

	printf("Sorted list: \n");
	
        for (counter = 0;counter <= n-1; ++counter)

            {
                printf("%3d", a[counter]);
            }
			

}
