// Function pointer in C
#include <stdio.h>

int add(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }
int mul(int x, int y) { return x * y; }
int div(int x, int y) { return x / y; }

int foo(int x, int y, int (*op)(int, int)) { return op(x,y); }

int main()
{
	int (*fp)(int, int);// fp is a pointer to a function which takes two int as parameters
			    // and returns an answer of type int	
	
	printf("Result: %d\n", add(5,4));

	fp = add; // fp points to fn add()

	printf("Result: %d\n", fp(5,4));
	
	printf("fp: %p  add: %p\n", fp, add);

	printf("Result: %d\n", foo(5,4,add));
	printf("Result: %d\n", foo(5,4,sub));

        printf("Result: %d\n", foo(5,4,mul));
        printf("Result: %d\n", foo(5,4,div));

	printf("sizeof fptr: %d\n", sizeof(fp));

}
