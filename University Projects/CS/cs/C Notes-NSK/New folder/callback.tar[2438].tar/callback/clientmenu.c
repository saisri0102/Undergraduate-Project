//  menu

#include <stdio.h>
#include "menu.h"

int main()
{
	void (*fp[3])(int) = {function1, function2, function3};
	int choice;

	printf("enter a num betwen 0 and 2, 3 to end.\n");
	scanf("%d", &choice);

	while (choice >= 0 && choice < 3)
	      {
		(*fp[choice]) (choice);

		printf("enter a num betwen 0 and 2, 3 to end.\n");
	        scanf("%d", &choice);
 	      }
}
	


 
