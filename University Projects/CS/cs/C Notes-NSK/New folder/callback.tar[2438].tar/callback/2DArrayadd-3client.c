// Addition of two matrices using add()
#include <stdio.h>
#include "2DArrayadd-3.h"

#define ROW 5
#define COL 5

int main()
{
	int m, n;
	int choice;

	int a[ROW][COL];
	int b[ROW][COL];
	int c[ROW][COL];
	void (*fp) (int a[ROW][COL], int b[ROW][COL], int c[ROW][COL],
                       int m, int n);   
	

	printf("Enter the order of a matrix \n");
	scanf("%d%d", &m, &n);
	
	printf("Ener matrix-a elements one by one.\n"); 
	readMat(a, m, n);

	printf("Ener matrix-b elements one by one.\n");
	readMat(b, m, n);

	printf("Enter 1- addition 2- subtraction.\n");
	scanf("%d", &choice);
#if 0
	switch (choice)
	{
	   case 1:
		    addMat(a, b, c, m, n);
		    fp = addMat;
		    foo(1, fp);
	   break;

	   case 2:
		    subMat(a, b, c, m, n);
                    fp = subMat;
                    foo(2, fp);
           break;
	}	
#endif
       foo(choice, a, b, c, m, n,fp);          

	printMat(c, m, n);
}
