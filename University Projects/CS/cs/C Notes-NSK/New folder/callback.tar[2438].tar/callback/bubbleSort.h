// bubble sort algorithm

void bubble(int x[], const int size, int (*compare)(int a, int b));
int ascending(int a, int b);
int descending(int a, int b);


