// Function pointer in C

#ifndef CALSI_H
#define CALSI_H

int add(int x, int y); 
int sub(int x, int y);
int mul(int x, int y);
int div(int x, int y);

int foo(int x, int y, int (*op)(int, int));

#endif

