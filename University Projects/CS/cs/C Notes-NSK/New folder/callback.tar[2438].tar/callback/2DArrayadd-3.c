
// addition and subtraction of 2 matrices
#define ROW 5
#define COL 5
#include <stdio.h>

void readMat(int a[ROW][COL], int m, int n)
{
	int i, j;

 	for (i = 0;i <= m-1;++i)
            {
                for (j = 0;j <= n-1;++j)
                    {
                        scanf("%d", &a[i][j]);
                    }

            }		

}

void printMat(int a[ROW][COL], int m, int n)
{
	int i, j;

	 for (i = 0;i <= m-1;++i)
            {
                for (j = 0;j <= n-1;++j)
                    {
                       printf("%d ", a[i][j]);
                    }
                printf("\n");
            }

}

void addMat(int a[ROW][COL], int b[ROW][COL], int c[ROW][COL], int m, int n)
{
	int i, j;

	  for (i = 0;i <= m-1;++i)
            {
                for (j = 0;j <= n-1;++j)
                    {
                       c[i][j] = a[i][j] + b[i][j];
                    }
            }
}
#if 0
void (*fp)(int a[ROW][COL], int b[ROW][COL], int c[ROW][COL], int m, int n)
{

	fp = addMat;

} 
#endif

void subMat(int a[ROW][COL], int b[ROW][COL], int c[ROW][COL], int m, int n)
{
        int i, j;

          for (i = 0;i <= m-1;++i)
            {
                for (j = 0;j <= n-1;++j)
                    {
                       c[i][j] = a[i][j] - b[i][j];
                    }
            }
}

void foo(int choice, int a[ROW][COL], int b[ROW][COL], int c[ROW][COL],
         int m,int n, void (*fp)(int a[ROW][COL], int b[ROW][COL],
                                 int c[ROW][COL], int m,int n))
{

	switch (choice)
        {
           case 1:
                    fp = addMat;
	 	    addMat(a, b, c, m, n);	
           break;

           case 2:
		    fp = subMat;
                    subMat(a, b, c, m, n);
           break;
        }
}

