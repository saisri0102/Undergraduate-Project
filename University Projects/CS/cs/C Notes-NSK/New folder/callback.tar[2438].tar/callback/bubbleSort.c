// bubble sort algorithm
#include "bubbleSort.h"

void bubble(int x[], const int size, int (*compare)(int a, int b))
{
	int pass; // 
	int count; // comparison counter

	void swap(int* ptr_1, int* prt_2); // prototype

	for (pass = 1; pass <= size - 1;++pass)
	    {
		for (count = 0; count <= size - 2;++count)

	            {
			if ((*compare)(x[count], x[count + 1]))

			    {
				swap(&x[count], &x[count + 1]);
	           	    }				
		     }
	     }
}// end of fn bubble()

void swap(int* ptr_1, int* ptr_2)
{
	int hold;// temp var

	hold   = *ptr_1;
	*ptr_1 = *ptr_2;
	*ptr_2 = hold;
}
	
int ascending(int a, int b) { return b < a; } // swap if b < a
int descending(int a, int b) { return b > a; } // swap if b > a


