//
#define ROW 5
#define COL 5

void readMat(int a[ROW][COL], int m, int n);
void printMat(int a[][COL], int m, int n);
//void printMat(int (*a)[COL], int m, int n);//a is a pointer to a row 
void addMat(int a[ROW][COL], int b[ROW][COL], int c[ROW][COL], int m, int n);

void subMat(int a[ROW][COL], int b[ROW][COL], int c[ROW][COL], int m, int n);

void foo(int choice, int a[ROW][COL], int b[ROW][COL], int c[ROW][COL],
         int m,int n, void (*fp)(int a[ROW][COL], int b[ROW][COL],
                                int c[ROW][COL], int m,int n));





  
