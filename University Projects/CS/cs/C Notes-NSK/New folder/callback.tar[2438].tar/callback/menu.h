//  menu 

void function1(int a);
void function2(int b);
void function3(int c);
