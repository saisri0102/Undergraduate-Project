// menu 
#include <stdio.h>

void function1(int a){ printf("Entered value: %d\n", a); }
void function2(int b){ printf("Entered value: %d\n", b); }
void function3(int c){ printf("Entered value: %d\n", c); }

