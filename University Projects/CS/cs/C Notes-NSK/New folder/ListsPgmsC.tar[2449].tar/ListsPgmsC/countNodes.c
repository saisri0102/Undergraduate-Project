// creation and displying of all nodes
// counting the no of nodes in the list
#include <stdio.h>
#include <stdlib.h>
int main()
{

	struct node {
	       int data;
	       struct node* next;
	};

	typedef struct node node_t;

	node_t *head = NULL, // points to the newly created node
               *first = NULL,// always points to the beginning of the list
                *temp = NULL;// temp ptr points to the node
	int count = 0;
	int choice = 1;
	int value;
	
	while (choice)
        {      // dma to a node		
	       head = (node_t*) malloc(sizeof(node_t));

	       printf("Enter the data item.\n");
               scanf("%d", &value);
               head -> data = value;

	       if (first != NULL)
		  {
		    temp -> next = head;
		    temp = head;
	          }
	       else  // empty list
		  {
		    first = temp = head;	
                  }   		
		printf("Enter 1-continue 0-exit.\n ");
		scanf("%d", &choice);	
	}	   		
	
	temp -> next = NULL;

	temp = first; // reset temp to the beginning

	while (temp != NULL)
	{
           head = temp;
	   printf("%d ->", temp -> data);
	   ++count;
           // free the list
	   temp = temp -> next;

	   free(head);
	   first = temp;
 		
	}		

	printf("NULL\n");

	printf("No. of nodes in the list.%d\n", count);
}
