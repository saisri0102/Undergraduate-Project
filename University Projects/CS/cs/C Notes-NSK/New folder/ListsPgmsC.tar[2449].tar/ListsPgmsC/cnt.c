// creation and displying of all nodes
// counting the no of nodes in the list
// using function

#include <stdio.h>
#include <stdlib.h>
#include "cnt.h"

int countNodes(node_t* first)
{
	
        node_t* temp = first; // set temp to the beginning
	int count = 0;

        while (temp != NULL)
        {
           ++count;
           temp = temp -> next;
        }

	return count;   
}

void displayList(node_t* temp)
{


	 while (temp != NULL)
           {
           	printf("%d ->", temp -> data);
           	temp = temp -> next;
           }
	
	printf("NULL\n");
}

void freeList(node_t* temp)
{
	node_t* r;

	while (temp != NULL)
	{
	      r = temp -> next;
	      free(temp);
	      temp = r; 		
	}
}
