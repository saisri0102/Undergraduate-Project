// creation and displying of all nodes
// counting the no of nodes in the list
// using function

#include <stdio.h>
#include <stdlib.h>
#include "cnt.h"

int main()
{	
	node_t *head = NULL, // points to the newly created node
               *first = NULL,// always points to the beginning of the list
                *temp = NULL;// temp ptr points to the node
	
	int count;
	int choice = 1;
	int value;

	while (choice)
        {      // dma to a node		
	       head = (node_t*) malloc(sizeof(node_t));

	       printf("Enter the data item.\n");
               scanf("%d", &value);
              
	       head -> data = value;

	       if (first != NULL)
		  {
		    temp -> next = head;
		    temp = head;
	          }
	       else
		  {
		    first = temp = head;	
                  }   		
		printf("Enter 1-continue 0-exit.\n ");
		scanf("%d", &choice);	
	}	   		
	
	temp -> next = NULL;

	temp = first; // reset temp to the beginning
	
	count = countNodes(first);

	displayList(first);
  
	
	freeList(first);
	
	printf("No. of nodes in the list.%d\n", count);

}

