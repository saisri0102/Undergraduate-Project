// creation and displying of all nodes
// counting the no of nodes in the list
// using function

#include <stdio.h>
#include <stdlib.h>


// declaration   
#ifndef NODE_H
#define NODE_H
	struct node {
	       int data;
	       struct node* next;
	};

	typedef struct node node_t;
	int countNodes(node_t* ); // 1- prototype
	void displayList(node_t*); //1- prototype
	void freeList(node_t*); // 1
#endif

