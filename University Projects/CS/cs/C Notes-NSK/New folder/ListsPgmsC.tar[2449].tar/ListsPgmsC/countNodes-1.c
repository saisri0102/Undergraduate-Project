// creation and displying of all nodes
// counting the no of nodes in the list
// using function

#include <stdio.h>
#include <stdlib.h>


// declaration   

	struct node {
	       int data;
	       struct node* next;
	};

	typedef struct node node_t;
int main()
{	
	node_t *head = NULL, // points to the newly created node
               *first = NULL,// always points to the beginning of the list
                *temp = NULL;// temp ptr points to the node
	
	int count = 0;
	int k;
	int choice = 1;

	int countNodes(node_t* ); // 1- prototype
	void displayList(node_t*); //1- prototype
	void freeList(node_t*); // 1

	while (choice)
        {      // dma to a node		
	       head = (node_t*) malloc(sizeof(node_t));

	       printf("Enter the data item.\n");
               scanf("%d", &(head -> data));

	       if (first != NULL)
		  {
		    temp -> next = head;
		    temp = head;
	          }
	       else
		  {
		    first = temp = head;	
                  }   		
		printf("Enter 1-continue 0-exit.\n ");
		scanf("%d", &choice);	
	}	   		
	
	temp -> next = NULL;

	temp = first; // reset temp to the beginning
	
	k = countNodes(first);
	displayList(first);
  
	
	while (temp != NULL)
	{
	   printf("%d ->", temp -> data);
	   ++count;
           head = temp;
           // free the list
	//   free(head);		
	   temp = temp -> next;
	   first = temp; 		
	}		

	printf("NULL\n");
	
	freeList(first);
	
	printf("No. of nodes in the list.%d\n", count);

	printf("# of nodes.%d\n", k);
}

int countNodes(node_t* first)
{
	
        node_t* temp = first; // set temp to the beginning
	int count = 0;

        while (temp != NULL)
        {
           printf("%d ->", temp -> data);
           ++count;
           temp = temp -> next;
        }

        printf("NULL\n");
       
	return count;   
}

void displayList(node_t* temp)
{


	 while (temp != NULL)
           {
           	printf("%d ->", temp -> data);
           	temp = temp -> next;
           }
	
	printf("NULL\n");
}

void freeList(node_t* temp)
{
	node_t* r;

	while (temp != NULL)
	{
	      r = temp -> next;
	      free(temp);
	      temp = r; 		
	}
}
