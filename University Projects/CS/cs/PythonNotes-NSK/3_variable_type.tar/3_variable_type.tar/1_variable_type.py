# file: 1_variable_type.py
# discussed:
#	constant (literal)
#	variable
#	type
#		has set of values
#		has set of operators
#		specified what happens when the operators are applied
#		does not specify how operators are applied
#	any value has a fixed type
#	type of a variable depends on the value assigned to it

a = 10
print(a, type(a))
a = "fool"
print(a, type(a))
a = 3.14
print(a, type(a))
a = True
print(a, type(a))  # values of bool type : False True
a = 2 + 3j
print(a, type(a))
#---------------------
a = (11, 22, 33, 44)
print(a, type(a)) # tuple

a = [11, 22, 33, 44]
print(a, type(a)) # list

a = {11, 22, 33, 44}
print(a, type(a)) # set

a = {11 : 22, 33 : 44}
print(a, type(a)) # dict












