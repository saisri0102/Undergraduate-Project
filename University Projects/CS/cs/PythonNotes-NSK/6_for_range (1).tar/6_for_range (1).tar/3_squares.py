# display all squares less than or equal to a given number
n = int(input("enter an integer : "))
i = 1
while i * i <= n :
	print("Square of ", i, " is ", i * i)
	i += 1

