# file: 6_selection.py

# dangling else problem
#	two if and single else
#	else is paired with the if based on indentation
a = int(input())
b = int(input())
c = int(input())
if a == b :
	if b == c :
		print("nooru")
else:  # paired with the outer if; control reaches here if a not equal to b
		print("innoru")


if a == b :
	if b == c :
		print("munnuru")
	else: # paired with the inner if; control reaches here if a equals b and b is not equal to c
		print("naanuru")

