# file: 2_loop.py
# display 1 2 4 8 ... until n
# find the total
n = 100
t = 1
r = 2
total = 0
while t <= n:
	total = total + t
	print(t, end = " ")
	t = t * r
print()
print("total : ", total)
