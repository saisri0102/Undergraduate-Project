# file: 1_loop.py

# do something repeatedly
# add numbers from 1 to n
# 1 + 2 + 3 + 4 + ... + n

# sequential control:
#	# of statements 
#	executed one after the other

# loop control
#	# of statements
#	repeated executed

# selection control
#	groups of statements
#	execute one of the groups

# loop:
#	while statement
#	syntax(grammar)
#	while <expr> :
#		<stmt>
#		<stmt>
#		...

#	while it is raining
#		I will keep waiting
#	I will go home

#	while I am thirsty
#		I will keep on drinking water

# expr of while : true or false

# display 1 2 3 until n
"""
# Test 1
# wrong program; infinite loop
n = 5
i = 1
while i <= n : 
    print(i)
i = i + 1
print("happy tests")
"""

# there are statements which have # of statements within them
# first statement is like a leader of the group
#	rest are part of it
# to indicate this, leader is the first statement, ends with :
# 	group of statements under the leader : called suite or block

# leader :
#	suite
# leader has a colon
# suite should have higher indentation compared to the leader

"""
# Test 2
# print is not a leader
# putting : after print will be an error
# statement following print cannot have higher indentation
n = 5
i = 1
while i <= n : 
    print(i)
       i = i + 1
print("happy tests")
"""

# ok
"""
# Test 3
n = 5
i = 1
while i <= n : 
    print(i, end = " ")
    i = i + 1
print()
print("happy tests")
"""

# error
# when we decrease the indentation, it should match one of the earlier statements
"""
# Test 4
n = 5
i = 1
while i <= n : 
    print(i, end = " ")
    i = i + 1
  print()
print("happy tests")
"""














