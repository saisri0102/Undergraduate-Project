# file: 3_loop.py
# reverse a given number
n = int(input("enter an integer : "))
rev = 0
while n :
	rev = rev * 10 + n % 10
	n //= 10
print("reverse number : ", rev)

