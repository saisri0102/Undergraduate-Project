# file: 7_combined.py
# find all factors of a given number

# factors can vary from 1 to n

# algorithm:
# get n
# factor <- 1
# while factor <= n do
#	if factor is a factor of n
#		display the factor
#	increment factor

n = int(input("enter an integer : "))
f = 1
while f <= n :
	if n % f == 0 :
		print(f, end = " ")
	f = f +  1  # f += 1
print()



