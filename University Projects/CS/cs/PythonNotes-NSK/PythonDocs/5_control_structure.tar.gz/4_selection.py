# file: 4_selection.py

# selection
# syntax :
# if <expr> :
#	<suite>

# or
# if <expr> :
#	<suite>
# else:
#	<suite>

# check whether given two strings are same
a = input("enter string 1  ")
b = input("enter string 2  ")

# check this out!
#if a = b :  #assignment is not an expr
#	print("equal")

if a == b :
	print("equal")
else:
	print("not equal")



