# file: 8_combined.py
"""
// Russian Peasant method
//	get two numbers (a, b)
//	initialize the product (say s) to 0
//	while a is not zero
//		if a is odd, then
//			add b to the product
//		halve a
//		double b
// s + a * b does not change => loop invariant
"""

a = 25
b = 40
s = 0
while a != 0 :
	if a % 2 == 1 :
		s += b
	a = a // 2
	b = b * 2
print(s)

