# file : 1_output.py
# output
#	output field separator : appears between fields in the output
#		default :  space
#		use sep to change this 
#	output record separator : appears at the end of each print
#		default : newline
#		use end to change this
"""
print("one", "two", "three")
print("four", "five")

print("one", "two", "three", sep = "-----", end = "\n*************\n")
print("four", "five", sep = "^^^^^^^^")
"""
"""
#end = "" # NO
print("to", end = "")
print("get", end = "")
print("her")
"""

"""
sep = "stupid"
print("rama", "krishna")
print("apple", "banana", sep = "fool")
print(sep)
"""
sep = " stupid "
# value of variable sep is substituted and nothing special
print("rama", "krishna", "parama ", "hamsa ", " not ", sep)

print("apple", "banana", "carrot", sep = sep)


