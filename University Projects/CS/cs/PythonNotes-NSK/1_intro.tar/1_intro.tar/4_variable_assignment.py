# file : 4_variable_assignment.py
# variable and assignment

"""
# version 1:
# find the area of a rectangle with given length and breadth
# input() : gets a string from the keyboard
# int() converts a string to an int
l = int(input())
b = int(input())
a = l * b
print("area : ", a)
"""
 
# version 2:
# find the area of a rectangle with given length and breadth
# input() : gets a string from the keyboard
# int() converts a string to an int
length = int(input("enter length of a rectangle : "))
breadth = int(input("enter breadth of a rectangle : "))
area = length * breadth
print("area : ", area)

 
