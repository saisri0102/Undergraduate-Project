# file: 1_list_traversal.py
# find the sum of all the element of the list
a = [11, 33, 22, 55, 44]
total = 0
for elem in a :
	total = total + elem
print("total : ", total)
