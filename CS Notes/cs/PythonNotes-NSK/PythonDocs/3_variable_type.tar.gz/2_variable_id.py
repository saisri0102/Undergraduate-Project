# file: 2_variable_id.py

# Test 1
# int : has only one element; scalar or simple or primitive type
a = 100
b = a
c = 50 + 50
d = [100, 200]
print(id(a))
print(id(b))
print(id(c))
print(id(d[0]))
# all have the same id

c = 1000
print("a : ", a) # has not changed
# only c changed, a, b, d[0] did not change.

# Test 2
# list : has # of elements ; structured or reference type

x = [11, 22]
y = x
print(x, id(x)) 
print(y, id(y))

x[0] = 33;  # y also changed
print(x, id(x)) 
print(y, id(y))

# Test 3:
x = [11, 22]
y = x
print(x, id(x)) 
print(y, id(y))

x = [33, 44]; # y does not change
print(x, id(x)) 
print(y, id(y))



