# snake ladder problem
# version 1
# Generate the first two rows only
for i in range(100, 90, -1):
	print(i, end = " ")
print()
for i in range(81, 91) :
	print(i, end = " ")
print()

