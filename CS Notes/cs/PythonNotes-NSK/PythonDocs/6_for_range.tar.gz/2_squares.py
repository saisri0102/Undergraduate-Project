# display all squares from 1 to n
n = int(input("enter an integer : "))
for i in range(1, n + 1):
	print("Square of ", i, " is ", i * i)
	

