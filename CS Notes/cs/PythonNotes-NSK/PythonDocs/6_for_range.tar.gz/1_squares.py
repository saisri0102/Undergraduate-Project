# display all squares from 1 to n
n = int(input("enter an integer : "))
i = 1
while i <= n :
	print("Square of ", i, " is ", i * i)
	i += 1


