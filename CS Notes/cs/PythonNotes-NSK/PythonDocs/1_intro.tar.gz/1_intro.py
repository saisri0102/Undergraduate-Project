# programming in a langauge called python
# is a high level language
#	far different from the machine language of the computer
#	easier for human beings to communicate
# designed by Rossum in early 90s
# named after the Monty Python circus show
# version : 3.x
# require a translator to convert from Python to the machine language
#	compiler : converts the whole program in a single stroke
#	interpreter : converts line by line
#	hybrid model : anything between these two

# way of talking in Python:
#	1. interactive mode
#	python
#	>>> <here enter commands>
#   2. batch mode
#	create a file of commands in python
#	run them together

3 * 4   # does not show anything on the screen
# use print for displaying
print(5 * 6)
# print : said to be a function
# does not give back anything - does not return anything
# it does display













