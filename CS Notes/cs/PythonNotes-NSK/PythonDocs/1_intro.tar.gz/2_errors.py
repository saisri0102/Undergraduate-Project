# syntax and runtime errors
print("zero")
# note: put # in the beginning of the next statements(lines) to avoid syntax error or
# correct the error to proceed.
print('this will be syntax error")
 print('another syntax error')  #observe that the statement does not start from the first col

print("one")
print(10/0)  # gives runtime error
print("two")

