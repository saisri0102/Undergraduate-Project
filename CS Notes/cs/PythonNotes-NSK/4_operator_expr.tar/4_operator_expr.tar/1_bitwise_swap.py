# file: 1_bitwise_swap.py
# interchange two int variables without using another variable
a = 5
b = 6
print("before : ")
print("a : ", a)
print("b : ", b)

a = a ^ b  # 0101 ^ 0110 => 0011 => 3
b = a ^ b  # 0011 ^ 0110 => 0101 => 5
a = a ^ b  # 0011 ^ 0101 => 0110 => 6

print("after : ")
print("a : ", a)
print("b : ", b)


