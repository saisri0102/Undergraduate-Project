# file: 3_polymorphic_operator.py
# polymorphic operator
# +
print(10 + 20) # 30
print("one" + "two") # onetwo # concatenation
print([10, 20] + [30, 40]) # [10, 20, 30, 40] # concatenation

# *
print(2 * 3) # 6
print("2" * 3) # 222 # replicate
print("python" * 3) # pythonpythonpython
print((10, 20) * 3)  #(10, 20, 10, 20, 10, 20)
print(3 * "2") # 33


