# file: 2_relational_operator.py
# relational operators
#	used to compare two quantities
#	< <= > >= == != in is
#   result : bool 
#		values : False True
# 
# simple comparison
print("10 == 10", 10 == 10) # True
print("3 > 2 : ", 3 > 2) # True

# cascading comparison
# a op1 b op2 c is same as (a op1 b) and (b op2 c)
# Python knows math better than any other language!!
 
print("3 > 2 > 1 : ", 3 > 2 > 1)
print("10 == 10 == 10 : ", 10 == 10 == 10)
# a > b > c :  (a > b) and (b > c)

# string comparison:
# compares the corresponding characters based on the coding - based how the character
#	is stored as a number in the computer - until a mismatch or one or both strings end.

print("cat > car : ", "cat" > "car") # True  # "t" > "r"
print("cat > cattle : ", "cat" > "cattle" ) # False : second string is longer and therefore 
											# bigger
print("cat == Cat : ", "cat" == "Cat") # False : "C" < "c"
print("apple > z : ", "apple" > "z") # False ; comparison not based on the length
print("zebra > abcdefgh : ", "zebra" > "abcedefgh") # True "z" > a"; rest do not matter

# list comparison:
# rule same as that of string - compare the corresponding elements until a mismatch or one or
#	both ends
print([10, 20, 30] > [10, 25]) # False  20 > 25 is false

print([(10, 20), "abcd" ] >[(10, 20), "abcc" ]) # True  d of abcd > last c of abcc

# in : membership
print("c in cat", "c" in "cat")  #True
print("at in cat", "at" in "cat") # True

print("ct in cat", "ct" in "cat")  #False
print("ta in cat", "ta" in "cat")  #False


print("cat" > "cat")  # False
print("cat" >= "cat") # True



# logical operators
#	not
#	and
#	or
a = 10
b = 10
print (not (a == b) )  # False
print(a > 5 and b > 5) # True
print(a > 5 and b < 5) # False
print(a < 5 and b < 5) # False

a = 0
b = 10
#print( b / a > 5) # division by zero
print( a == 0 or b / a > 5)
# short ckt evaluation
#	evaluate a logical expression left to right
#	stop the evaluation as soon as the truth or the falsehood is found

# Observe this is similar to Don't cares in K maps.









































