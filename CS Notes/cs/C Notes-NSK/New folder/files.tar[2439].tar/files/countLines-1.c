// Count Lines in input - 1st ver

#include <stdio.h>
int main()
{

	int c, nl = 0;

	while ((c = getchar()) != EOF)
	{
	       if (c == '\n')	
		   ++nl;
	}

	printf("No. of Lines: %d\n", nl);
} 

