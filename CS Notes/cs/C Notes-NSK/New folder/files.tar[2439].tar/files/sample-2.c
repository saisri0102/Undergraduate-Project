// Copy input to output -2nd ver

#include <stdio.h>
int main()
{

	int c;

	while ((c = getchar()) != EOF)
	{
		putchar(c);
	}
} 

