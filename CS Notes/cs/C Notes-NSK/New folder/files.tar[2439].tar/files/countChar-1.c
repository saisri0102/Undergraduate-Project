// Count chars in input - 1st ver

#include <stdio.h>
int main()
{

	long nc = 0l;

	while (getchar() != EOF)
	{
		++nc;
	}

	printf("No. of chars: %d\n", nc);
} 

