// Count chars in input - 2nd ver

#include <stdio.h>
int main()
{

	long double nc;

	for (nc = 0.L; getchar() != EOF; ++nc)
	{
	     ;
	}

	printf("No. of chars: %.0Lf\n", nc);
} 

